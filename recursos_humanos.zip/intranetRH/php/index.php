






<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <form action="ingresar.php" method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="">
        <br>
        <label for="ap_paterno">Apellido Paterno:</label>
        <input type="text" name="ap_paterno" value="">
        <br>
        <label for="ap_materno">Apellido Materno:</label>
        <input type="text" name="ap_materno" value="">
        <br>
        <label for="fecha_nac">Fecha de nacimiento:</label>
        <input type="text" name="fecha_nac" value="">
        <br>
        <label for="edad">Edad:</label>
        <input type="text" name="edad" value="">
        <br>
        <label for="nacionalidad">Nacionalidad:</label>
        <input type="text" name="nacionalidad" value="">
        <br>
        <label for="originario">Originario:</label>
        <input type="text" name="originario" value="">
        <br>
        <label for="sexo">Sexo:</label>
        <input type="text" name="sexo" value="">
        <br>
        <label for="celular">Celular:</label>
        <input type="text" name="celular" value="">
        <br>
        <label for="correo">Correo:</label>
        <input type="text" name="correo" value="">
        <br>
        <label for="domicilio">Domicilio:</label>
        <input type="text" name="domicilio" value="">
        <br>
        <input type="submit" name="btnGuardar" value="Guardar">
    </form>
</body>
</html>
<?php

    require_once 'conexion.php';


    $id = $_GET['id_empleado']


?>